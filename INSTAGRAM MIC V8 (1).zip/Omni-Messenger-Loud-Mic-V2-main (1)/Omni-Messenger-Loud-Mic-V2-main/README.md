# FBX MUNNA INSTAGRAM PRO MIX

Instagram Web microphone maximizer.

## Site
- https://www.instagram.com/*


## Use
1. Load unpacked
2. Unlock with key + code
3. Open Instagram Web → reload → call / live
